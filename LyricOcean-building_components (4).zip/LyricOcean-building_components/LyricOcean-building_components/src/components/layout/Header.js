import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";

const styles = {
  nav: {
    fontFamily: "Anton",
    fontWeight: "500",
    height: "100vh",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between",
    alignItems: "center",
  },
  navLink: {
    fontSize: "24px",
    alignItems: "center",
    color: "white",
  },
};

const Header = () => {
  return (
    <header>
      <Navbar bg="dark" variant="dark" expand="lg">
        <Container fluid>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav style={styles.nav}>
              <Nav.Link href="#home">Home</Nav.Link>
              <Nav.Link href="#home">Albums</Nav.Link>
              <Nav.Link href="#home">Artists</Nav.Link>
              <Nav.Link href="#home">Playlists</Nav.Link>
              <Nav.Link href="#home">Radio</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </header>
  );
};

export default Header;